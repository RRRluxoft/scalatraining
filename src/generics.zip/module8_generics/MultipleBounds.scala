package module8_generics

object MultipleBounds extends App {
  // type variable can have both an upper and a lower bound
  // T <% Lower <% Lower
  // for example: T <% Comparable[T] <% Person
  class Person(val name:String) extends Comparable[Person] {
    override def compareTo(o: Person): Int =
      o.name.compareTo(name)
  }
  class Employee(_name:String) extends Person(_name)
  class Pair[T <% Comparable[T] <% Person](val first: T, val second: T) {
    def smaller = if (first.compareTo(second) < 0) first else second
  }
  val smith = new Employee("Smith")
  val johnson = new Person("Johnson")

  val p = new Pair(smith, johnson)
  println ( p.smaller.name ) // Smith

}
