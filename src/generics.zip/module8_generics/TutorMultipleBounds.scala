package module8_generics

object TutorMultipleBounds extends App {
  // type variable can have both an upper and a lower bound
  // or several lower bounds
  // T <% Lower <% Lower
  class Person(val name:String) extends Comparable[Person] {
    override def compareTo(o: Person): Int =
      o.name.compareTo(name)
  }
  class Employee(_name:String) extends Person(_name)
  // TODO define Pair with first and second which takes
  // TODO any type which implements Comparable and extends Person

  // TODO implement method smaller by comparing names of first and second Person
  // TODO use compareTo for comparing
  val smith = new Employee("Smith")
  val johnson = new Person("Johnson")

  // TODO uncomment this
  //val p = new Pair(smith, johnson)
  //println ( p.smaller.name ) // Smith

}
