package module8_generics

import scala.collection.mutable.ArrayBuffer

object ManifestContextBound {

  // Manifest Context Bound: using Manifest to create classes
  // When type is defined as T:Manifest, compiler will look for
  // implicit Manifest[T] and use it to create objects
  // syntax: [T:Manifest]

  // create array
  def createArrayBuffer[T: Manifest](first: T, second:T) = {
    val a = new ArrayBuffer[T](2)
    a(0) = first
    a(1) = second
    a
  }
  val arr1 = createArrayBuffer(1,2) // created ArrayBuffer[Int]
  // compiler locates the implicit Manifest[Int]

  // arr1 += "hi" // error: cannot put String to ArrayBuffer[Int]
  arr1 += 1 // correct - put Int

}
